﻿using ASP.Net_Day1.BL;
namespace ASP.Net_Day1.DL
{
    public class ProductDL
    {
        public static List<Product> Products = new List<Product>();

        public static void AddProduct(Product product)
        {
            Products.Add(product);
        }
        public static void loaddata()
        {
            Product p1 = new Product();
            p1.ProductName = "Biscuit";
            p1.description = "strong taste and quality";
            p1.Price = 350;
            AddProduct(p1);
            Product p2 = new Product();
            p2.ProductName = "Chocolate";
            p2.description = "strong taste and quality";
            p2.Price = 350;
            AddProduct(p2);
            Product p3 = new Product();
            p3.ProductName = "Candy";
            p3.description = "strong taste and quality";
            p3.Price = 350;
            AddProduct(p3);
        }
    }
}
