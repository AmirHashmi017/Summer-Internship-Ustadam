﻿namespace ASP.Net_Day1.BL
{
    public class Product
    {
        public string ProductName;
        public  string description;
        public int Price;
    }
}
