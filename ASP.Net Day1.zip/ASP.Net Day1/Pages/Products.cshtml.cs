using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ASP.Net_Day1.BL;
using ASP.Net_Day1.DL;
namespace ASP.Net_Day1.Pages
{
    public class ProductsModel : PageModel
    {
        public List<Product>Products= new List<Product>();
        public void OnGet()
        {
            ProductDL.loaddata();
            Products = ProductDL.Products;
        }
    }
}
