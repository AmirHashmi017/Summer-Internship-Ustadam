﻿using Day1.BL;
using System.Data.SqlClient;
namespace Day1.DL
{
    public class UserDL
    {
        private static IConfiguration Configuration { get; set; }
        public static List<User> Users = new List<User>();
        public static void Initialize(IConfiguration configuration)
        {
            Configuration= configuration;
        }
        public static bool SignUp(User user)
        {
            if (Login(user) == null && user!=null)
            {
                SqlConnection connection = new SqlConnection(Configuration.GetConnectionString("Default"));
                connection.Open();
                string query = String.Format("insert into MUSER (UserName, UserPassword,UserRole) VALUES('{0}', '{1}', '{2}')", user.GetName(), user.GetPassword(), user.GetRole());
                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();
                connection.Close();
                return true;
            }
            return false;
        }
        public static User Login(User user)
        {
            SqlConnection connection= new SqlConnection(Configuration.GetConnectionString("Default"));
            connection.Open();
            string query = String.Format("Select * from MUSER where UserName = '{0}' and UserPassword = '{1}'", user.GetName(), user.GetPassword());
            SqlCommand command=new SqlCommand(query, connection);
            SqlDataReader reader= command.ExecuteReader();
            if (reader.Read()) {

                User u1 = new User(reader.GetString(0), reader.GetString(1), reader.GetString(2));
                connection.Close();
                return u1;
            }
            connection.Close();
            return null;
        }
    }
}
