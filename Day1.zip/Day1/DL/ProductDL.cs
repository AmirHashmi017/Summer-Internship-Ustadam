﻿using Day1.BL;
using System.Data.SqlClient;
using System.Security.Cryptography.X509Certificates;
namespace Day1.DL
{
    public class ProductDL
    {
        private static IConfiguration Configuration;
        public static void Initialize(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public static bool AddProduct(Product product)
        {
            if (!IsProductExist(product.ProductId))
            {
                SqlConnection connection = new SqlConnection(Configuration.GetConnectionString("default"));
                connection.Open();
                string query = string.Format("INSERT INTO Products(ProductID,ProductName,ProductDescription)" + "Values ('{0}','{1}','{2}')", product.ProductId, product.ProductName, product.ProductDescription);
                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();
                connection.Close();
                return true;
            }
            return false;
        }
        public static bool IsProductExist(int productID)
        {
            SqlConnection connection = new SqlConnection(Configuration.GetConnectionString("default"));
            connection.Open();
            string query = string.Format("Select * FROM Products WHERE ProductID={0}", productID);
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                connection.Close();
                return true;
            }
            connection.Close();
            return false;

        }
        public static List<Product> GetAllProducts()
        {
            List<Product> products = new List<Product>();
            SqlConnection connection = new SqlConnection(Configuration.GetConnectionString("default"));
            connection.Open();
            string query = string.Format("Select * FROM Products");
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                Product p = new Product(reader.GetInt32(0), reader.GetString(1), reader.GetString(2));
                products.Add(p);
            }
            connection.Close();
            return products;

        }
        public static bool BuyProduct(string UserName,int ProductID)
        {
            if (IsProductExist(ProductID)&&!string.IsNullOrWhiteSpace(UserName))
            {
                SqlConnection connection = new SqlConnection(Configuration.GetConnectionString("default"));
                connection.Open();
                string query = string.Format("INSERT INTO UserProducts(UserName,ProductID)" + "Values ('{0}','{1}')",UserName,ProductID);
                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();
                connection.Close();
                return true;
            }
            return false;
        }
        public static List<Product> GetAllMyProducts(string UserName)
        {
                List<Product> products = new List<Product>();
                SqlConnection connection = new SqlConnection(Configuration.GetConnectionString("default"));
                connection.Open();
                string query = string.Format("SELECT P.ProductID,P.ProductName,P.ProductDescription FROM Products AS P JOIN UserProducts AS U ON P.ProductID=U.ProductID WHERE U.UserName='{0}'",UserName);
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Product p = new Product(reader.GetInt32(0), reader.GetString(1), reader.GetString(2));
                    products.Add(p);
                }
                connection.Close();
                return products;
        }
        public static bool RemoveProduct(int ProductID)
        {
            if (!IsProductSold(ProductID))
            {
                SqlConnection connection = new SqlConnection(Configuration.GetConnectionString("default"));
                connection.Open();
                string query = string.Format("DELETE FROM Products WHERE ProductID={0}", ProductID);
                SqlCommand command = new SqlCommand(query, connection);
                int rowsaffected = command.ExecuteNonQuery();
                if (rowsaffected > 0)
                {
                    connection.Close();
                    return true;
                }
                connection.Close();
                return false;
            }
            return false;
        }
        public static bool IsProductSold(int productID)
        {
            SqlConnection connection = new SqlConnection(Configuration.GetConnectionString("default"));
            connection.Open();
            string query = string.Format("Select * FROM UserProducts WHERE ProductID={0}", productID);
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                connection.Close();
                return true;
            }
            connection.Close();
            return false;

        }
    }
}
