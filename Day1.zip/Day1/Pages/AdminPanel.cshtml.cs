using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Day1.Pages
{
    public class AdminPanelModel : PageModel
    {
        public void OnGet()
        {
        }
        public IActionResult OnPost()
        {
            HttpContext.Session.Remove("Name");
            return RedirectToPage("Index");
        }
    }
}
