using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Day1.BL;
using Day1.DL;
namespace Day1.Pages
{
    public class UserProductsModel : PageModel
    {
        [BindProperty]
        public List<Product> Products { get; set; }
        public void OnGet()
        {
            string username = HttpContext.Session.GetString("Name");
            if (!string.IsNullOrWhiteSpace(username))
                Products = ProductDL.GetAllMyProducts(username);
        }
    }
}
