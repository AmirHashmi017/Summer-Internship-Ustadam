using Day1.BL;
using Day1.DL;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Day1.Pages
{
    public class DisplayProductsModel : PageModel
    {
        [BindProperty]
        public List<Product>Products { get; set; }
        /// <summary>
        /// </summary>
        public int ProductID { get; set; }
        public void OnGet()
        {
            Products=ProductDL.GetAllProducts();
        }
        public IActionResult OnPost(int ProductID)
        {
            if(ProductDL.RemoveProduct(ProductID))
            {
                return RedirectToPage();
            }
            return RedirectToPage();
        }
    }
}
