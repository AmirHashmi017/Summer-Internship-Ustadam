using Day1.BL;
using Day1.DL;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data;
using System.Xml.Linq;

namespace Day1.Pages
{
    public class AddProductModel : PageModel
    {
        [BindProperty]
        public int ProductID { get; set; }
        [BindProperty]
        public string ProductName { get; set; }
        [BindProperty]
        public string ProductDescription { get; set; }
        public void OnGet()
        {
           
        }
        public IActionResult OnPost()
        {
            try
            {
                if (!(string.IsNullOrEmpty(ProductName) || string.IsNullOrEmpty(ProductDescription)))
                {
                    Product p = new Product(ProductID, ProductName, ProductDescription);
                    if (ProductDL.AddProduct(p))
                    {
                        return RedirectToPage("SignIn");
                    }
                    return RedirectToPage();
                }
                return RedirectToPage();
            }
            catch (Exception ex) 
            {
                return Page();
            }

            }

    }
}
