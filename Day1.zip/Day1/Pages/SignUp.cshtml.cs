using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Day1.BL;
using Day1.DL;
namespace Day1.Pages
{
    public class SignUpModel : PageModel
    {
        [BindProperty]
        public string Name { get; set; }
        [BindProperty]
        public string Password { get; set; }
        [BindProperty]
        public string Role {  get; set; }
        public void OnGet()
        {
        }
        public IActionResult OnPost()
        {
            try
            {
                if (!(string.IsNullOrEmpty(Name) || string.IsNullOrEmpty(Password) || string.IsNullOrEmpty(Role)))
                {
                    User user = new User(Name, Password, Role);
                    if (UserDL.SignUp(user))
                    {
                        return RedirectToPage("SignIn");
                    }
                    return RedirectToPage();
                }
                return RedirectToPage();
            }
            catch (Exception ex)
            {
                return Page();
            }
        }
    }
}
