using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Day1.BL;
using Day1.DL;
namespace Day1.Pages
{
    public class Index1Model : PageModel
    {
        [BindProperty]
        public string Name { get; set; }
        [BindProperty]
        public string Password { get; set; }
        public User u1;
        public void OnGet()
        {
        }
        public IActionResult OnPost()
        {
            try
            {
                if (!(string.IsNullOrEmpty(Name) || string.IsNullOrEmpty(Password)))
                {
                    User u1 = new User(Name, Password);
                    User StoredUser = UserDL.Login(u1);
                    if (StoredUser != null)
                    {
                        HttpContext.Session.SetString("Name", StoredUser.GetName());
                        if (StoredUser.GetRole().ToLower() == "client")
                            return RedirectToPage("UserPanel");
                        else if (StoredUser.GetRole().ToLower() == "admin")
                        {
                            return RedirectToPage("AdminPanel");
                        }
                    }
                    return RedirectToPage();
                }
                return RedirectToPage();
            }
            catch(Exception ex)
            {
                return Page();
            }
        }
    }
}
