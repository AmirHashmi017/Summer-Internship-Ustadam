﻿namespace Day1.BL
{
    public class User
    {
        private string Name;
        private string Password;
        private string Role;
        public string GetName() { return Name; }
        public string GetPassword() { return Password; }
        public string GetRole() { return Role; }
        public void SetName(string name) { Name = name; }
        public void SetPassword(string password) { Password = password; }
        public void SetRole(string role) { Role = role; }  
        public User(string name, string password)
        {
            Name = name;
            Password = password;
        }
        public User(string name, string password,string role)
        {
            Name = name;
            Password = password;
            Role = role;
        }
    }
}
