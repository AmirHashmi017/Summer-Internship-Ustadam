﻿namespace Day1.BL
{
    public class Product
    {
        public int ProductId;
        public string ProductName;
        public string ProductDescription;
        public Product(int productId, string productName, string productDescription)
        {
            ProductId = productId;
            ProductName = productName;
            ProductDescription = productDescription;
        }
    }
}
